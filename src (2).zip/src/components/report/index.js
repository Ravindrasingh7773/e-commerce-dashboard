import React from "react";
import styles from "./style.module.css";
import MainDashboardHeading from "../mainDashboardHeding";
import image1 from "../../assets/images/report1.png";
import image2 from "../../assets/images/report2.png";
import image3 from "../../assets/images/report3.png";
import img1 from "../../assets/images/table1.png";
import img2 from "../../assets/images/table2.png";
import img3 from "../../assets/images/table3.png";
import img4 from "../../assets/images/table4.png";
import ReactECharts from 'echarts-for-react';

const option = {
  title: {
    text: 'World Population'
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    }
  },                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
  legend: {},
  grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true
  },
  yAxis: {
    type: 'value',
    boundaryGap: [0, 0.01]
  },
  xAxis: {
    type: 'category',
    data: ['jan','feb','mar','apr','may','jun'   ,'Jul','Aug','Sep','Oct','Nov','Dec' ]
  },
  series: [
    {
      name: '2011',
      type: 'bar',   
      data: [18203, 23489, 29034, 104970, 131744, 630230]
    },
    {
      name: '2012',
      type: 'bar',
      data: [19325, 23438, 31000, 121594, 134141, 681807]
    }
  ]
};

// var _panelImageURL = ROOT_PATH + '/data/asset/img/custom-gauge-panel.png';
// var _animationDuration = 1000;
// var _animationDurationUpdate = 1000;
// var _animationEasingUpdate = 'quarticInOut';
// var _valOnRadianMax = 200;
// var _outerRadius = 200;
// var _innerRadius = 170;
// var _pointerInnerRadius = 40;
// var _insidePanelRadius = 140;
// var _currentDataIndex = 0;
// function renderItem(params, api) {
//   var valOnRadian = api.value(1);
//   var coords = api.coord([api.value(0), valOnRadian]);
//   var polarEndRadian = coords[3];
//   var imageStyle = {
//     image: _panelImageURL,
//     x: params.coordSys.cx - _outerRadius,
//     y: params.coordSys.cy - _outerRadius,
//     width: _outerRadius * 2,
//     height: _outerRadius * 2
//   };
//   return {
//     type: 'group',
//     children: [
//       {
//         type: 'image',
//         style: imageStyle,
//         clipPath: {
//           type: 'sector',
//           shape: {
//             cx: params.coordSys.cx,
//             cy: params.coordSys.cy,
//             r: _outerRadius,
//             r0: _innerRadius,
//             startAngle: 0,
//             endAngle: -polarEndRadian,
//             transition: 'endAngle',
//             enterFrom: { endAngle: 0 }
//           }
//         }
//       },
//       {
//         type: 'image',
//         style: imageStyle,
//         clipPath: {
//           type: 'polygon',
//           shape: {
//             points: makePionterPoints(params, polarEndRadian)
//           },
//           extra: {
//             polarEndRadian: polarEndRadian,
//             transition: 'polarEndRadian',
//             enterFrom: { polarEndRadian: 0 }
//           },
//           during: function (apiDuring) {
//             apiDuring.setShape(
//               'points',
//               makePionterPoints(params, apiDuring.getExtra('polarEndRadian'))
//             );
//           }
//         }
//       },
//       {
//         type: 'circle',
//         shape: {
//           cx: params.coordSys.cx,
//           cy: params.coordSys.cy,
//           r: _insidePanelRadius
//         },
//         style: {
//           fill: '#fff',
//           shadowBlur: 25,
//           shadowOffsetX: 0,
//           shadowOffsetY: 0,
//           shadowColor: 'rgba(76,107,167,0.4)'
//         }
//       },
//       {
//         type: 'text',
//         extra: {
//           valOnRadian: valOnRadian,
//           transition: 'valOnRadian',
//           enterFrom: { valOnRadian: 0 }
//         },
//         style: {
//           text: makeText(valOnRadian),
//           fontSize: 50,
//           fontWeight: 700,
//           x: params.coordSys.cx,
//           y: params.coordSys.cy,
//           fill: 'rgb(0,50,190)',
//           align: 'center',
//           verticalAlign: 'middle',
//           enterFrom: { opacity: 0 }
//         },
//         during: function (apiDuring) {
//           apiDuring.setStyle(
//             'text',
//             makeText(apiDuring.getExtra('valOnRadian'))
//           );
//         }
//       }
//     ]
//   };
// }
// function convertToPolarPoint(renderItemParams, radius, radian) {
//   return [
//     Math.cos(radian) * radius + renderItemParams.coordSys.cx,
//     -Math.sin(radian) * radius + renderItemParams.coordSys.cy
//   ];
// }
// function makePionterPoints(renderItemParams, polarEndRadian) {
//   return [
//     convertToPolarPoint(renderItemParams, _outerRadius, polarEndRadian),
//     convertToPolarPoint(
//       renderItemParams,
//       _outerRadius,
//       polarEndRadian + Math.PI * 0.03
//     ),
//     convertToPolarPoint(renderItemParams, _pointerInnerRadius, polarEndRadian)
//   ];
// }
// function makeText(valOnRadian) {
//   // Validate additive animation calc.
//   if (valOnRadian < -10) {
//     alert('illegal during val: ' + valOnRadian);
//   }
//   return ((valOnRadian / _valOnRadianMax) * 100).toFixed(0) + '%';
// }
// const saleOption = {
//   animationEasing: _animationEasingUpdate,
//   animationDuration: _animationDuration,
//   animationDurationUpdate: _animationDurationUpdate,
//   animationEasingUpdate: _animationEasingUpdate,
//   dataset: {
//     source: [[1, 156]]
//   },
//   tooltip: {},
//   angleAxis: {
//     type: 'value',
//     startAngle: 0,
//     show: false,
//     min: 0,
//     max: _valOnRadianMax
//   },
//   radiusAxis: {
//     type: 'value',
//     show: false
//   },
//   polar: {},
//   series: [
//     {
//       type: 'custom',
//       coordinateSystem: 'polar',
//       renderItem: renderItem
//     }
//   ]
// };
// setInterval(function () {
 //   var nextSource = [[1, Math.round(Math.random() * _valOnRadianMax)]];
 //   myChart.setOption({
 //     dataset: {
 //       source: nextSource
 //     }
 //   });
 // }, 3000);

const Report = () => {
  return (
    <div className={styles.report}>
      <MainDashboardHeading
        title={"Reports"}
        fillBtn={true}
        title2={"Export"}
      />
      <div className={styles.r_customer_growth}>
        <div className={styles.rcg_wrapper}>
          <div className={styles.rcgw_growth}>
            <div className={styles.rcgwg_month}>
              <h5>Customer Growth</h5>
              <span>Last 12 Months</span>
            </div>
            <div className={styles.return_new_customer}>
              <p>
                <span
                  style={{
                    background: "#D7DBEC",
                    display: "inline-block",
                    width: "12px",
                    height: "12px",
                    borderRadius: "4px",
                    marginRight: "8px",
                  }}></span>
                Returning customers
              </p>
              <p>
                <span
                  style={{
                    background: "#1E5EFF",
                    display: "inline-block",
                    width: "12px",
                    height: "12px",
                    borderRadius: "4px",
                    marginRight: "8px",
                  }}></span>
                New customers
              </p>
            </div>
            <ReactECharts option={option} />
          </div>  
          <div className={styles.rcgw_totleUsers}>
            <div className={styles.rcgwt_existing}>
              <span>Existing Users</span>
              <h6>5.653</h6>
              <p>22.45%</p>
            </div>
            <div className={styles.rcgwt_existing1}>
              <span>New Users</span>
              <h6>1.650</h6>
              <p>15.34%</p>
            </div>
            <div className={styles.rcgwt_totle}>
              <span>Total Visits</span>
              <h6>9.504</h6>
              <p>18.25%</p>
            </div>
            <div className={styles.rcgwt_unique}>
              <span>Unique Visits</span>
              <h6>5.423</h6>
              <p>10.24%</p>
            </div>
          </div>
          <div className={styles.rcgw_conversion}>
            <div className={styles.rcgwc_salesgoal}>
              <h5>Sales Goal</h5>
              {/* <ReactECharts option={saleOption} /> */}
              <div className={styles.rcgwcs_sold}>
                <span>Sold for:</span>
                <p>$15.000</p>
              </div>
              <div className={styles.rcgwcs_sold}>
                <span>Month goal:</span>
                <p>$20.000</p>
              </div>
              <div className={styles.rcgwcs_sold}>
                <span>Left:</span>
                <p>$5.000</p>
              </div>
            </div>
            <div className={styles.rcgwc_rate}>
              <div className={styles.rcgwc_salesgoal}>
                <h5>Conversion Rate</h5>
                <div className={styles.rcgwcs_goalPre1}>
                  <span>100%</span>
                </div>
                <div className={styles.rcgwcs_sold}>
                  <span>Cart:</span>
                  <p>35%</p>
                </div>
                <div className={styles.rcgwcs_sold}>
                  <span>Checkout:</span>
                  <p>29%</p>
                </div>
                <div className={styles.rcgwcs_sold}>
                  <span>Purchase:</span>
                  <p>25%</p>
                </div>
              </div>
            </div>
            <div className={styles.rcgwc_value}>
              <h5>Average Order Value</h5>
              <div className={styles.rcgwcv_month}>
                <p>This Month</p>
                <span>$48.90</span>
                <p>Previous Month</p>
                <span>$48.90</span>
              </div>
            </div>
          </div>
          <div className={styles.rcgw_demographi}>
            <div className={styles.rcgwd_image}>
              <img src={image1} />
            </div>
            <div className={styles.rcgwd_visits}>
              <div className={styles.rcgwdv_visits}>
                <img src={image2} />
              </div>
              <div className={styles.rcgwdv_visits}>
                <img src={image3} />
              </div>
            </div>
          </div>
          <div className={styles.rcgw_topCustomer}>
            <div className={styles.drt_recent}>
              <h5>Top Customers</h5>
              <table>
                <tr>
                  <th>Name</th>
                  <th>Orders</th>
                  <th>Spent</th>
                </tr>
                <tr>
                  <td>
                    <div className={styles.lee_henry}>
                      <span>A</span>
                      <span>Lee Henry</span>
                    </div>
                  </td>
                  <td>52</td>
                  <td>$969.37</td>
                </tr>
                <tr>
                  <td>
                    <div className={styles.lee_henry}>
                      <span>M</span>
                      <span>Myrtie McBride</span>
                    </div>
                  </td>
                  <td>24.05.2023</td>
                  <td>$124.97</td>
                </tr>
                <tr>
                  <td>
                    <div className={styles.lee_henry}>
                      <span>T</span>
                      <span>Tommy Walker</span>
                    </div>
                  </td>
                  <td>24.05.2023</td>
                  <td>$124.97</td>
                </tr>
                <tr>
                  <td>
                    <div className={styles.lee_henry}>
                      <span>K</span>
                      <span>Lela Cannon</span>
                    </div>
                  </td>
                  <td>24.05.2023</td>
                  <td>$124.97</td>
                </tr>
                <tr>
                  <td>
                    <div className={styles.lee_henry}>
                      <span>S</span>
                      <span>Jimmy Cook</span>
                    </div>
                  </td>
                  <td>24.05.2023</td>
                  <td>$124.97</td>
                </tr>
              </table>
            </div>
            <div className={styles.drt_productSold}>
              <div className={styles.drt_recent}>
                <h5>Top Products</h5>
                <table className={styles.drtr_table}>
                  <tr>
                    <th>Name</th>
                    <th>Clicks</th>
                    <th>Units Sold</th>
                  </tr>
                  <tr>
                    <td className={styles.t_row_img}>
                      <span>
                        <img src={img1} />
                      </span>
                      Men Grey Hoodie
                    </td>
                    <td>$49.90</td>
                    <td>204</td>
                  </tr>
                  <tr>
                    <td className={styles.t_row_img}>
                      <span>
                        <img src={img2} />
                      </span>
                      Men Grey Hoodie
                    </td>
                    <td>$49.90</td>
                    <td>204</td>
                  </tr>
                  <tr>
                    <td className={styles.t_row_img}>
                      <span>
                        <img src={img3} />
                      </span>
                      Men Grey Hoodie
                    </td>
                    <td>$49.90</td>
                    <td>204</td>
                  </tr>
                  <tr>
                    <td className={styles.t_row_img}>
                      <span>
                        <img src={img4} />
                      </span>
                      Men Grey Hoodie
                    </td>
                    <td>$49.90</td>
                    <td>204</td>
                  </tr>
                  <tr>
                    <td className={styles.t_row_img}>
                      <span>
                        <img src={img1} />
                      </span>
                      Men Grey Hoodie
                    </td>
                    <td>$49.90</td>
                    <td>204</td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div className={styles.store_funnel_row}>
            
          </div>
        </div>
      </div>
    </div>
  );
};
export default Report;
